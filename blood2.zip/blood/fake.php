<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Blood Donor's Network</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style type="text/css">
	ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
     font-color: #CF000F;
}



</style>


</head>

<body>
	<ul><li><a href="index.php" style="text-align: center; font-size:30px;">Blood Donor's Network</a></li></ul>
	<br><br><br><br><br><br><br><br><br><br>

	<h2 style="text-align: center; font-color: red; top: 50%;"><b> Don't get fooled with this button! </b> </h2>



</body>
</html>